import React from 'react';
import ReactDOM from 'react-dom/client';

import './styles/tokens.css';
import './styles/base.css';
import './styles/glass.css';
import './styles/storefront.css';
import './styles/admin.css';

import { App } from './App';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error('Root element #root not found in document.');
}

ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
